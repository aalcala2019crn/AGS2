<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel=”stylesheet” href=”<?php bloginfo( ‘template_url’ ); ?>/960.css type=”text/css” media=”screen” />
  <link rel=”stylesheet” href=”<?php bloginfo( ‘template_url’ ); ?>/estil.css type=”text/css” media=”screen” />

    <link rel="stylesheet" href="css/12.css">
    <link rel="stylesheet" href="css/estil.css">

  <title>cars and films</title>
</head>
<body>

  <div class="container_12 cap">

      <h1 class="grid_6 push_3">cars<span style="color:grey">and</span>films</h1>
      <img class="grid_12" src="img/back.png"/>

  </div>



  <div class="cos">
        <div class="container_12 cos1">

            <img id="logo" class="grid_4" src="img/small_pulp.jpg"/>
            <img id="logo" class="grid_4" src="img/small_taxi.jpg"/>
            <img id="logo" class="grid_4" src="img/small_bond.jpg"/>


                <li class="grid_4"><p>Pulp Fiction<p></li>
                <li class="grid_4"><p>Taxi Driver<p></li>
                <li class="grid_4"><p>Goldfinger<p></li>

        </div>

        <div class="container_12 cos2">

            <img id="logo" class="grid_4" src="img/small_ghost.jpg"/>
            <img id="logo" class="grid_4" src="img/small_bean.jpg"/>
            <img id="logo" class="grid_4" src="img/small_back.jpg"/>


                <li class="grid_4"><p>Ghost Busters<p></li>
                <li class="grid_4"><p>Mr. Bean<p></li>
                <li class="grid_4"><p>Pulp Fiction<p></li>

        </div>

        <div class="container_12 cos3">

            <img id="logo" class="grid_4" src="img/small_rider.jpg"/>
            <img id="logo" class="grid_4" src="img/small_team.jpg"/>
            <img id="logo" class="grid_4" src="img/small_break.jpg"/>


                <li class="grid_4"><p>Knight Rider<p></li>
                <li class="grid_4"><p>The A-Team<p></li>
                <li class="grid_4"><p>Breaking Bad<p></li>

        </div>
  </div>

  <div class="container_12 peu">

      <img class="grid_2 push_5" src="img/logo_carsandfilms.png"/>

  </div>


</body>
</html>
